import React from 'react';
import Carousel from './Carousel';

function App() {
  return (
    <>
      <Carousel />
    </>
  );
}

export default App;
